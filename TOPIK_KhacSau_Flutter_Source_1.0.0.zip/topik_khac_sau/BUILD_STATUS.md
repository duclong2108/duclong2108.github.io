# Build and verification status

Date: 2026-11-18

## Passed in the generation environment

- `python3 tool/check_data.py`: PASS.
- 88/88 vocabulary seed IDs unique; every level is 1–6.
- 290/290 grammar IDs and patterns unique; every level is 1–6.
- UTF-8 JSON parsing: PASS.
- Control-character scan: PASS.
- Balanced delimiter scan across all Dart source files: PASS.
- No TODO, FIXME, placeholder throw or Lorem Ipsum markers in `lib/` and `test/`.

## Not executable in the generation environment

The container did not contain Flutter, Dart, Android SDK, Gradle or ADB. Attempts to fetch the official Flutter/Android toolchains and their mirrors were rejected by the container's outbound-download policy with HTTP 403. Therefore this environment could not truthfully produce or execute an APK, `flutter analyze`, `flutter test`, or an emulator smoke test.

Do **not** interpret the static checks above as proof of zero runtime defects. Run `tool/BUILD_ANDROID.bat` or `tool/build_android.sh` on a machine with Flutter/Android SDK; those scripts stop immediately if format, analyzer, unit tests, or release build fails. The included GitHub Actions workflow performs the same gates and uploads the APK only after all gates pass.
