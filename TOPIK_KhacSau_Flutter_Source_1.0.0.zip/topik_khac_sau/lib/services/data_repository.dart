import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import '../models/models.dart';

class SyncResult {
  const SyncResult(this.items, this.message);
  final List<LearningItem> items;
  final String message;
}

class DataRepository {
  static const _vocabUrl =
      'https://topikvocab.foldalpha.com/download/topik-vocab-vi.csv';
  static const _levelsUrl =
      'https://everykoreans.com/downloads/topik-vocabulary-basic.csv';
  static const _grammarUrl =
      'https://everykoreans.com/downloads/korean-grammar-list.csv';

  Future<File> get _cacheFile async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/learning_items_v1.json');
  }

  Future<List<LearningItem>> load() async {
    try {
      final file = await _cacheFile;
      if (await file.exists()) {
        final raw = jsonDecode(await file.readAsString()) as List<dynamic>;
        final cached = raw
            .map((e) => LearningItem.fromCache(e as Map<String, dynamic>))
            .toList();
        if (cached.isNotEmpty) return cached;
      }
    } catch (_) {
      // Cache hỏng không làm app ngừng chạy; dùng dữ liệu đóng gói.
    }
    return loadSeeds();
  }

  Future<List<LearningItem>> loadSeeds() async {
    final results = await Future.wait([
      rootBundle.loadString('assets/data/vocab_seed.json'),
      rootBundle.loadString('assets/data/grammar_seed.json'),
    ]);
    final vocab = (jsonDecode(results[0]) as List<dynamic>)
        .map((e) => LearningItem.fromVocab(e as Map<String, dynamic>));
    final grammar = (jsonDecode(results[1]) as List<dynamic>)
        .map((e) => LearningItem.fromGrammar(e as Map<String, dynamic>));
    return [...vocab, ...grammar];
  }

  Future<SyncResult> syncFullPack() async {
    // Các nguồn độc lập: một nguồn phụ tạm lỗi không được làm mất dữ liệu
    // tải thành công từ nguồn còn lại.
    final downloads = await Future.wait([
      _download(_vocabUrl),
      _download(_levelsUrl),
      _download(_grammarUrl),
    ]);
    if (downloads[0] == null && downloads[2] == null) {
      throw HttpException('Không kết nối được các nguồn dữ liệu');
    }

    final levelRows = _csv(downloads[1] ?? const []);
    final levels = <String, int>{};
    for (final row in levelRows) {
      final word = _first(row, ['korean', 'word', '단어', 'headword']);
      final level = int.tryParse(_first(row, ['level', 'topik_level', '급수']));
      if (word.isNotEmpty && level != null) levels[word] = level.clamp(1, 6).toInt();
    }

    final vocabRows = _csv(downloads[0] ?? const []);
    final vocab = <LearningItem>[];
    for (var i = 0; i < vocabRows.length; i++) {
      final row = vocabRows[i];
      final word = _first(row, ['word', 'korean', '단어']);
      if (word.isEmpty) continue;
      final grade = _first(row, ['grade', 'nikl_grade', 'level']);
      final fallbackLevel = switch (grade.toUpperCase()) {
        'A' || 'BEGINNER' => i < 500 ? 1 : 2,
        'B' || 'INTERMEDIATE' => i < 2000 ? 3 : 4,
        'C' || 'ADVANCED' => i < 4200 ? 5 : 6,
        _ => 1 + ((i * 6) ~/ (vocabRows.length == 0 ? 1 : vocabRows.length)),
      };
      vocab.add(LearningItem(
        id: 'remote-v-${_stableId(word)}',
        korean: word,
        meaning: _first(row, ['meaning', 'vietnamese', 'meaning_vi', 'translation']),
        example: _first(row, ['example_korean', 'example', 'example_ko']),
        level: (levels[word] ?? fallbackLevel).clamp(1, 6).toInt(),
        type: ItemType.vocabulary,
        partOfSpeech: _first(row, ['part_of_speech', 'pos']),
        hanja: _first(row, ['hanja', 'origin']),
        source: 'NIKL / FoldAlpha / CheesePotato',
      ));
    }

    final grammarRows = _csv(downloads[2] ?? const []);
    final grammar = <LearningItem>[];
    for (var i = 0; i < grammarRows.length; i++) {
      final row = grammarRows[i];
      final pattern = _first(row, ['pattern', 'grammar', '문법']);
      if (pattern.isEmpty) continue;
      final band = _first(row, ['level', 'band']).toLowerCase();
      final level = band.contains('begin')
          ? (i.isEven ? 1 : 2)
          : band.contains('inter')
              ? (i.isEven ? 3 : 4)
              : (i.isEven ? 5 : 6);
      grammar.add(LearningItem(
        id: 'remote-g-${_stableId(pattern)}',
        korean: pattern,
        meaning: _first(row, ['meaning_vi', 'vietnamese']),
        meaningEn: _first(row, ['meaning', 'english']),
        example: _first(row, ['example', 'example_korean', 'example_ko']),
        level: level,
        type: ItemType.grammar,
        source: 'CheesePotato grammar list',
      ));
    }

    final seed = await loadSeeds();
    final byKey = <String, LearningItem>{};
    for (final item in [...seed, ...vocab, ...grammar]) {
      final key = '${item.type.name}:${item.korean.trim()}';
      final old = byKey[key];
      if (old == null || item.displayMeaning.length > old.displayMeaning.length) {
        byKey[key] = item;
      }
    }
    final merged = byKey.values.toList()
      ..sort((a, b) {
        final level = a.level.compareTo(b.level);
        return level != 0 ? level : a.korean.compareTo(b.korean);
      });
    final file = await _cacheFile;
    await file.writeAsString(jsonEncode(merged.map((e) => e.toJson()).toList()),
        flush: true);
    return SyncResult(
      merged,
      'Đã nạp ${vocab.length} từ vựng và ${grammar.length} mẫu ngữ pháp; '
          'sau gộp còn ${merged.length} mục.',
    );
  }

  Future<List<int>?> _download(String url) async {
    try {
      final response =
          await http.get(Uri.parse(url)).timeout(const Duration(seconds: 40));
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return response.bodyBytes;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  List<Map<String, String>> _csv(List<int> bytes) {
    var text = utf8.decode(bytes, allowMalformed: true);
    if (text.startsWith('\ufeff')) text = text.substring(1);
    final matrix = <List<String>>[];
    var row = <String>[];
    var field = StringBuffer();
    var quoted = false;
    for (var i = 0; i < text.length; i++) {
      final char = text[i];
      if (char == '"') {
        if (quoted && i + 1 < text.length && text[i + 1] == '"') {
          field.write('"');
          i++;
        } else {
          quoted = !quoted;
        }
      } else if (char == ',' && !quoted) {
        row.add(field.toString());
        field = StringBuffer();
      } else if ((char == '\n' || char == '\r') && !quoted) {
        if (char == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++;
        row.add(field.toString());
        field = StringBuffer();
        if (row.any((e) => e.trim().isNotEmpty)) matrix.add(row);
        row = <String>[];
      } else {
        field.write(char);
      }
    }
    if (field.isNotEmpty || row.isNotEmpty) {
      row.add(field.toString());
      matrix.add(row);
    }
    if (matrix.length < 2) return const [];
    final headers = matrix.first.map((e) => e.trim().toLowerCase()).toList();
    return matrix.skip(1).map((values) {
      final map = <String, String>{};
      for (var i = 0; i < headers.length; i++) {
        map[headers[i]] = i < values.length ? values[i].trim() : '';
      }
      return map;
    }).toList();
  }

  String _first(Map<String, String> row, List<String> keys) {
    for (final key in keys) {
      final value = row[key]?.trim() ?? '';
      if (value.isNotEmpty) return value;
    }
    return '';
  }

  String _stableId(String input) {
    var hash = 0x811c9dc5;
    for (final code in input.codeUnits) {
      hash ^= code;
      hash = (hash * 0x01000193) & 0x7fffffff;
    }
    return hash.toRadixString(16);
  }
}
