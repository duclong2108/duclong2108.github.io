import 'dart:math';

import '../models/models.dart';

/// Scheduler kiểu SM-2 cải tiến: thất bại quay lại trong vài phút, còn khoảng
/// cách dài tăng theo độ dễ. Mọi phép tính đều thuần hàm để dễ kiểm thử.
class MemoryScheduler {
  const MemoryScheduler();

  ReviewRecord schedule(
    ReviewRecord? previous,
    String itemId,
    RecallRating rating,
    DateTime now,
  ) {
    final old = previous ?? ReviewRecord(itemId: itemId, due: now);
    var repetitions = old.repetitions;
    var lapses = old.lapses;
    var ease = old.ease;
    var interval = old.intervalDays;
    late Duration delay;

    if (rating == RecallRating.again) {
      repetitions = 0;
      lapses += 1;
      ease = max(1.3, ease - 0.20).toDouble();
      interval = 0;
      delay = const Duration(minutes: 10);
    } else if (rating == RecallRating.hard) {
      repetitions += 1;
      ease = max(1.3, ease - 0.15).toDouble();
      interval = interval <= 0 ? 1.0 : max(1.0, interval * 1.2).toDouble();
      delay = Duration(hours: max(12, (interval * 24).round()));
    } else if (rating == RecallRating.good) {
      repetitions += 1;
      if (repetitions == 1) {
        interval = 1.0;
      } else if (repetitions == 2) {
        interval = 3.0;
      } else {
        interval = max(4.0, interval * ease).toDouble();
      }
      delay = Duration(hours: (interval * 24).round());
    } else {
      repetitions += 1;
      ease = min(3.0, ease + 0.15).toDouble();
      interval = interval <= 0
          ? 4.0
          : max(4.0, interval * ease * 1.3).toDouble();
      delay = Duration(hours: (interval * 24).round());
    }

    return ReviewRecord(
      itemId: itemId,
      due: now.add(delay),
      repetitions: repetitions,
      lapses: lapses,
      intervalDays: interval,
      ease: ease,
      lastReviewed: now,
    );
  }
}
