import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models/models.dart';
import 'services/data_repository.dart';
import 'services/scheduler.dart';

class AppState extends ChangeNotifier {
  AppState({DataRepository? repository})
      : repository = repository ?? DataRepository();

  final DataRepository repository;
  final MemoryScheduler scheduler = const MemoryScheduler();
  final FlutterTts tts = FlutterTts();

  List<LearningItem> items = const [];
  final Map<String, ReviewRecord> records = {};
  final Map<String, int> dailyReviews = {};
  bool loading = true;
  bool syncing = false;
  String? error;
  int dailyGoal = 30;
  int selectedLevel = 0;

  Future<File> get _progressFile async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/progress_v1.json');
  }

  Future<void> initialize() async {
    loading = true;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      dailyGoal = prefs.getInt('dailyGoal') ?? 30;
      try {
        await tts.setLanguage('ko-KR');
        await tts.setSpeechRate(0.42);
      } catch (_) {
        // Thiếu engine TTS không được chặn phần học chữ và SRS.
      }
      items = await repository.load();
      await _loadProgress();
      error = null;
    } catch (e) {
      error = 'Không thể khởi tạo: $e';
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> _loadProgress() async {
    final file = await _progressFile;
    if (!await file.exists()) return;
    try {
      final json = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
      for (final entry in (json['records'] as Map<String, dynamic>? ?? {}).entries) {
        records[entry.key] =
            ReviewRecord.fromJson(entry.value as Map<String, dynamic>);
      }
      for (final entry
          in (json['dailyReviews'] as Map<String, dynamic>? ?? {}).entries) {
        dailyReviews[entry.key] = (entry.value as num).toInt();
      }
    } catch (_) {
      records.clear();
      dailyReviews.clear();
    }
  }

  Future<void> _saveProgress() async {
    final file = await _progressFile;
    final data = {
      'records': records.map((key, value) => MapEntry(key, value.toJson())),
      'dailyReviews': dailyReviews,
    };
    await file.writeAsString(jsonEncode(data), flush: true);
  }

  String dayKey([DateTime? value]) {
    final date = value ?? DateTime.now();
    return '${date.year.toString().padLeft(4, '0')}-'
        '${date.month.toString().padLeft(2, '0')}-'
        '${date.day.toString().padLeft(2, '0')}';
  }

  int get reviewedToday => dailyReviews[dayKey()] ?? 0;
  int get dueCount => records.values.where((r) => r.isDue(DateTime.now())).length;
  int get masteredCount => records.values.where((r) => r.isMastered).length;
  int get learnedCount => records.length;

  int get streak {
    var count = 0;
    var cursor = DateTime.now();
    while ((dailyReviews[dayKey(cursor)] ?? 0) > 0) {
      count++;
      cursor = cursor.subtract(const Duration(days: 1));
    }
    return count;
  }

  List<LearningItem> filteredItems({ItemType? type, String query = ''}) {
    final normalized = query.trim().toLowerCase();
    return items.where((item) {
      if (type != null && item.type != type) return false;
      if (selectedLevel != 0 && item.level != selectedLevel) return false;
      if (normalized.isEmpty) return true;
      return item.korean.toLowerCase().contains(normalized) ||
          item.displayMeaning.toLowerCase().contains(normalized) ||
          item.example.toLowerCase().contains(normalized);
    }).toList();
  }

  List<LearningItem> makeSession({int limit = 20, ItemType? type}) {
    final pool = filteredItems(type: type);
    if (pool.isEmpty) return const [];
    final now = DateTime.now();
    final due = pool
        .where((i) => records[i.id]?.isDue(now) ?? false)
        .toList()
      ..shuffle();
    final unseen = pool.where((i) => !records.containsKey(i.id)).toList()
      ..shuffle(Random(now.millisecondsSinceEpoch));
    final result = <LearningItem>[...due.take(limit)];
    if (result.length < limit) {
      result.addAll(unseen.take(limit - result.length));
    }
    return result;
  }

  Future<void> rate(LearningItem item, RecallRating rating) async {
    final now = DateTime.now();
    records[item.id] = scheduler.schedule(records[item.id], item.id, rating, now);
    dailyReviews[dayKey(now)] = reviewedToday + 1;
    notifyListeners();
    await _saveProgress();
  }

  Future<void> speak(String korean, {double rate = 0.42}) async {
    try {
      await tts.stop();
      await tts.setLanguage('ko-KR');
      await tts.setSpeechRate(rate.clamp(0.2, 0.75).toDouble());
      await tts.speak(korean);
    } catch (_) {
      error = 'Thiết bị chưa có giọng đọc tiếng Hàn. Hãy cài Korean TTS trong cài đặt hệ thống.';
      notifyListeners();
    }
  }

  Future<void> stopSpeaking() => tts.stop();

  Future<String> sync() async {
    syncing = true;
    error = null;
    notifyListeners();
    try {
      final result = await repository.syncFullPack();
      items = result.items;
      return result.message;
    } catch (e) {
      error = 'Đồng bộ thất bại: $e';
      rethrow;
    } finally {
      syncing = false;
      notifyListeners();
    }
  }

  Future<void> setDailyGoal(int value) async {
    dailyGoal = value.clamp(5, 200).toInt();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('dailyGoal', dailyGoal);
    notifyListeners();
  }

  void setLevel(int level) {
    selectedLevel = level.clamp(0, 6).toInt();
    notifyListeners();
  }

  Future<void> resetProgress() async {
    records.clear();
    dailyReviews.clear();
    final file = await _progressFile;
    if (await file.exists()) await file.delete();
    notifyListeners();
  }

  @override
  void dispose() {
    unawaited(tts.stop());
    super.dispose();
  }
}
