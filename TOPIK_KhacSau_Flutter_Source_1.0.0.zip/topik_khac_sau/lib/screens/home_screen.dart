import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models/models.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({required this.state, super.key});
  final AppState state;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.state,
      builder: (context, _) {
        if (widget.state.loading) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final pages = [
          Dashboard(state: widget.state, onNavigate: (value) => setState(() => index = value)),
          LibraryScreen(state: widget.state),
          PassiveScreen(state: widget.state),
          ProgressScreen(state: widget.state),
          SettingsScreen(state: widget.state),
        ];
        return Scaffold(
          body: SafeArea(child: IndexedStack(index: index, children: pages)),
          bottomNavigationBar: NavigationBar(
            selectedIndex: index,
            onDestinationSelected: (value) => setState(() => index = value),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Hôm nay'),
              NavigationDestination(icon: Icon(Icons.menu_book_rounded), label: 'Thư viện'),
              NavigationDestination(icon: Icon(Icons.headphones_rounded), label: 'Thụ động'),
              NavigationDestination(icon: Icon(Icons.insights_rounded), label: 'Tiến độ'),
              NavigationDestination(icon: Icon(Icons.tune_rounded), label: 'Cài đặt'),
            ],
          ),
        );
      },
    );
  }
}

class Dashboard extends StatelessWidget {
  const Dashboard({required this.state, required this.onNavigate, super.key});
  final AppState state;
  final ValueChanged<int> onNavigate;

  @override
  Widget build(BuildContext context) {
    final progress = (state.reviewedToday / state.dailyGoal).clamp(0.0, 1.0).toDouble();
    final vocabCount = state.items.where((e) => e.type == ItemType.vocabulary).length;
    final grammarCount = state.items.where((e) => e.type == ItemType.grammar).length;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      children: [
        Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Center(child: Text('한', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800))),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('안녕하세요!', style: TextStyle(fontSize: 14)),
                Text('TOPIK Khắc Sâu', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              ]),
            ),
            _Pill(icon: Icons.local_fire_department_rounded, text: '${state.streak} ngày'),
          ],
        ),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF7657FF), Color(0xFF9A6CFF)]),
            borderRadius: BorderRadius.circular(28),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Mục tiêu hôm nay', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text('${state.reviewedToday} / ${state.dailyGoal} lượt nhớ lại',
                style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 10,
                backgroundColor: Colors.white24,
                valueColor: const AlwaysStoppedAnimation(Colors.white),
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF6443E8)),
              onPressed: () => _openReview(context, state, null),
              icon: const Icon(Icons.bolt_rounded),
              label: Text(state.dueCount > 0 ? 'Ôn ${state.dueCount} mục đến hạn' : 'Bắt đầu phiên ghi nhớ'),
            ),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('Học theo cách của bạn', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: _ActionCard(
              color: const Color(0xFFE9F7F2),
              iconColor: const Color(0xFF12805C),
              icon: Icons.translate_rounded,
              title: 'Từ vựng',
              subtitle: '$vocabCount mục',
              onTap: () => _openReview(context, state, ItemType.vocabulary),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _ActionCard(
              color: const Color(0xFFFFF0E7),
              iconColor: const Color(0xFFB95F20),
              icon: Icons.account_tree_rounded,
              title: 'Ngữ pháp',
              subtitle: '$grammarCount mẫu',
              onTap: () => _openReview(context, state, ItemType.grammar),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        _WideAction(
          icon: Icons.headphones_rounded,
          title: 'Nghe thụ động',
          subtitle: 'Nghe tiếng Hàn xen kẽ nghĩa khi làm việc khác',
          onTap: () => onNavigate(2),
        ),
        const SizedBox(height: 12),
        _WideAction(
          icon: Icons.draw_rounded,
          title: 'Nhớ mặt chữ',
          subtitle: 'Mở thư viện → chọn mục → luyện viết trên lưới',
          onTap: () => onNavigate(1),
        ),
        if (state.error != null) ...[
          const SizedBox(height: 16),
          MaterialBanner(
            content: Text(state.error!),
            actions: [TextButton(onPressed: () => onNavigate(4), child: const Text('Xem'))],
          ),
        ],
        const SizedBox(height: 18),
        Text(
          'Học sâu không đồng nghĩa học liên tục. Sau mỗi 20–25 phút, hãy nghỉ mắt và tự dùng từ trong câu mới.',
          style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.45),
        ),
      ],
    );
  }
}

Future<void> _openReview(BuildContext context, AppState state, ItemType? type) async {
  final session = state.makeSession(limit: 20, type: type);
  await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReviewScreen(state: state, session: session)));
}

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({required this.state, required this.session, super.key});
  final AppState state;
  final List<LearningItem> session;

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  int index = 0;
  bool revealed = false;
  int remembered = 0;

  @override
  Widget build(BuildContext context) {
    if (widget.session.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Ôn tập')),
        body: const Center(child: Padding(padding: EdgeInsets.all(28), child: Text('Không có mục phù hợp. Hãy đổi cấp TOPIK hoặc đồng bộ gói dữ liệu.'))),
      );
    }
    if (index >= widget.session.length) return _summary(context);
    final item = widget.session[index];
    return Scaffold(
      appBar: AppBar(
        title: Text('${index + 1} / ${widget.session.length}'),
        actions: [IconButton(onPressed: () => widget.state.speak(item.korean), icon: const Icon(Icons.volume_up_rounded))],
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: Column(children: [
          LinearProgressIndicator(value: (index + 1) / widget.session.length, minHeight: 7, borderRadius: BorderRadius.circular(9)),
          const SizedBox(height: 22),
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(28),
              onTap: () => setState(() => revealed = true),
              child: Ink(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  _Pill(icon: item.type == ItemType.vocabulary ? Icons.translate : Icons.account_tree, text: 'TOPIK ${item.level}'),
                  const SizedBox(height: 28),
                  Text(item.korean, textAlign: TextAlign.center, style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w800, height: 1.25)),
                  if (item.partOfSpeech.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(item.partOfSpeech, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  ],
                  const SizedBox(height: 28),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 220),
                    child: revealed
                        ? Column(key: const ValueKey('answer'), children: [
                            Text(item.displayMeaning.isEmpty ? 'Chưa có bản dịch — dùng ngữ cảnh ví dụ.' : item.displayMeaning,
                                textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, height: 1.4)),
                            if (item.example.isNotEmpty) ...[
                              const SizedBox(height: 18),
                              Text(item.example, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, height: 1.45)),
                            ],
                            if (item.hanja.isNotEmpty) ...[
                              const SizedBox(height: 10),
                              Text('Hán tự: ${item.hanja}'),
                            ],
                          ])
                        : Column(key: const ValueKey('prompt'), children: [
                            Icon(Icons.touch_app_rounded, color: Theme.of(context).colorScheme.primary),
                            const SizedBox(height: 8),
                            const Text('Tự trả lời thành tiếng, rồi chạm để lật'),
                          ]),
                  ),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 18),
          if (!revealed)
            SizedBox(width: double.infinity, child: FilledButton(onPressed: () => setState(() => revealed = true), child: const Text('Hiện đáp án')))
          else
            Row(children: [
              _RatingButton(label: 'Quên', color: const Color(0xFFB3261E), onTap: () => _rate(item, RecallRating.again)),
              const SizedBox(width: 7),
              _RatingButton(label: 'Khó', color: const Color(0xFFB35C00), onTap: () => _rate(item, RecallRating.hard)),
              const SizedBox(width: 7),
              _RatingButton(label: 'Nhớ', color: const Color(0xFF257A49), onTap: () => _rate(item, RecallRating.good)),
              const SizedBox(width: 7),
              _RatingButton(label: 'Dễ', color: const Color(0xFF315DA8), onTap: () => _rate(item, RecallRating.easy)),
            ]),
        ]),
      ),
    );
  }

  Future<void> _rate(LearningItem item, RecallRating rating) async {
    if (rating == RecallRating.good || rating == RecallRating.easy) remembered++;
    await widget.state.rate(item, rating);
    if (!mounted) return;
    setState(() {
      index++;
      revealed = false;
    });
  }

  Widget _summary(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Hoàn tất')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.celebration_rounded, size: 70, color: Color(0xFF6C4DFF)),
              const SizedBox(height: 18),
              const Text('Một lớp trí nhớ mới đã được tạo', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text('Bạn nhớ tốt $remembered/${widget.session.length} mục. Các mục quên sẽ quay lại sớm hơn.', textAlign: TextAlign.center),
              const SizedBox(height: 24),
              FilledButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.check), label: const Text('Về trang hôm nay')),
            ]),
          ),
        ),
      );
}

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({required this.state, super.key});
  final AppState state;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  String query = '';
  ItemType? type;

  @override
  Widget build(BuildContext context) {
    final items = widget.state.filteredItems(type: type, query: query);
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Thư viện', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          TextField(
            onChanged: (value) => setState(() => query = value),
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Tìm tiếng Hàn, nghĩa hoặc ví dụ…'),
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              ChoiceChip(label: const Text('Tất cả'), selected: type == null, onSelected: (_) => setState(() => type = null)),
              const SizedBox(width: 7),
              ChoiceChip(label: const Text('Từ vựng'), selected: type == ItemType.vocabulary, onSelected: (_) => setState(() => type = ItemType.vocabulary)),
              const SizedBox(width: 7),
              ChoiceChip(label: const Text('Ngữ pháp'), selected: type == ItemType.grammar, onSelected: (_) => setState(() => type = ItemType.grammar)),
              const SizedBox(width: 7),
              for (var level = 0; level <= 6; level++) ...[
                ChoiceChip(
                  label: Text(level == 0 ? 'Mọi cấp' : 'TOPIK $level'),
                  selected: widget.state.selectedLevel == level,
                  onSelected: (_) => widget.state.setLevel(level),
                ),
                const SizedBox(width: 7),
              ],
            ]),
          ),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
        child: Row(children: [Text('${items.length} mục', style: const TextStyle(fontWeight: FontWeight.w700)), const Spacer(), if (items.length > 500) const Text('Hiển thị 500 đầu')]),
      ),
      Expanded(
        child: ListView.separated(
          padding: const EdgeInsets.fromLTRB(20, 6, 20, 24),
          itemCount: min(items.length, 500),
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final item = items[index];
            final record = widget.state.records[item.id];
            return ListTile(
              tileColor: Theme.of(context).colorScheme.surfaceContainerLow,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              leading: CircleAvatar(child: Text('${item.level}')),
              title: Text(item.korean, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              subtitle: Text(item.displayMeaning.isEmpty ? 'Giải thích tiếng Anh/đang cập nhật' : item.displayMeaning, maxLines: 2, overflow: TextOverflow.ellipsis),
              trailing: Icon(record?.isMastered == true ? Icons.verified_rounded : Icons.chevron_right_rounded,
                  color: record?.isMastered == true ? const Color(0xFF25824D) : null),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ItemDetailScreen(state: widget.state, item: item))),
            );
          },
        ),
      ),
    ]);
  }
}

class ItemDetailScreen extends StatelessWidget {
  const ItemDetailScreen({required this.state, required this.item, super.key});
  final AppState state;
  final LearningItem item;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(item.type == ItemType.vocabulary ? 'Chi tiết từ vựng' : 'Chi tiết ngữ pháp'),
        actions: [IconButton(onPressed: () => state.speak(item.korean), icon: const Icon(Icons.volume_up_rounded))],
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 30), children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(28)),
          child: Column(children: [
            _Pill(icon: Icons.school_rounded, text: 'TOPIK ${item.level}'),
            const SizedBox(height: 18),
            Text(item.korean, textAlign: TextAlign.center, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            Text(item.displayMeaning.isEmpty ? 'Chưa có nghĩa tiếng Việt trong gói hiện tại.' : item.displayMeaning,
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, height: 1.4, fontWeight: FontWeight.w600)),
            if (item.meaningEn.isNotEmpty && item.meaning.isEmpty) ...[
              const SizedBox(height: 6),
              const Text('Giải thích nguồn bằng tiếng Anh', style: TextStyle(fontSize: 12)),
            ],
          ]),
        ),
        if (item.example.isNotEmpty) ...[
          const SizedBox(height: 20),
          const Text('Ngữ cảnh', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          _InfoBox(icon: Icons.format_quote_rounded, text: item.example),
        ],
        if (item.hanja.isNotEmpty) ...[
          const SizedBox(height: 12),
          _InfoBox(icon: Icons.history_edu_rounded, text: 'Gốc Hán: ${item.hanja}'),
        ],
        const SizedBox(height: 22),
        Row(children: [
          const Expanded(child: Text('Luyện nhớ mặt chữ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
          TextButton.icon(onPressed: () => state.speak(item.korean, rate: 0.3), icon: const Icon(Icons.record_voice_over), label: const Text('Nghe chậm')),
        ]),
        const Text('Dùng ngón tay viết đè theo chữ mờ, sau đó xóa và viết lại khi không nhìn mẫu.'),
        const SizedBox(height: 10),
        SizedBox(height: 310, child: WritingPad(prompt: item.korean)),
        const SizedBox(height: 16),
        _InfoBox(icon: Icons.source_rounded, text: 'Nguồn mục: ${item.source.isEmpty ? 'Gói dữ liệu ứng dụng' : item.source}'),
      ]),
    );
  }
}

class WritingPad extends StatefulWidget {
  const WritingPad({required this.prompt, super.key});
  final String prompt;

  @override
  State<WritingPad> createState() => _WritingPadState();
}

class _WritingPadState extends State<WritingPad> {
  final paths = <List<Offset>>[];
  bool showGuide = true;

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      GestureDetector(
        onPanStart: (d) => setState(() => paths.add([d.localPosition])),
        onPanUpdate: (d) => setState(() => paths.last.add(d.localPosition)),
        child: CustomPaint(
          painter: _TracePainter(paths: paths, prompt: widget.prompt, showGuide: showGuide, color: Theme.of(context).colorScheme.primary),
          size: Size.infinite,
        ),
      ),
      Positioned(
        right: 8,
        top: 8,
        child: Row(children: [
          IconButton.filledTonal(onPressed: () => setState(() => showGuide = !showGuide), icon: Icon(showGuide ? Icons.visibility_off : Icons.visibility)),
          const SizedBox(width: 6),
          IconButton.filledTonal(onPressed: () => setState(paths.clear), icon: const Icon(Icons.delete_sweep_rounded)),
        ]),
      ),
    ]);
  }
}

class _TracePainter extends CustomPainter {
  const _TracePainter({required this.paths, required this.prompt, required this.showGuide, required this.color});
  final List<List<Offset>> paths;
  final String prompt;
  final bool showGuide;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final border = Paint()..color = const Color(0xFFCBC6D8)..style = PaintingStyle.stroke..strokeWidth = 1;
    final rect = RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(22));
    canvas.drawRRect(rect, border);
    canvas.drawLine(Offset(size.width / 2, 0), Offset(size.width / 2, size.height), border);
    canvas.drawLine(Offset(0, size.height / 2), Offset(size.width, size.height / 2), border);
    if (showGuide) {
      final painter = TextPainter(
        text: TextSpan(text: prompt, style: TextStyle(color: const Color(0x226C4DFF), fontSize: min(88.0, size.width / max(2.0, prompt.length * 0.9)).toDouble(), fontWeight: FontWeight.w900)),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
        maxLines: 2,
      )..layout(maxWidth: size.width - 30);
      painter.paint(canvas, Offset((size.width - painter.width) / 2, (size.height - painter.height) / 2));
    }
    final ink = Paint()..color = color..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round..strokeWidth = 6..style = PaintingStyle.stroke;
    for (final path in paths) {
      if (path.length == 1) {
        canvas.drawCircle(path.first, 3, ink..style = PaintingStyle.fill);
        ink.style = PaintingStyle.stroke;
      } else {
        final p = Path()..moveTo(path.first.dx, path.first.dy);
        for (final point in path.skip(1)) p.lineTo(point.dx, point.dy);
        canvas.drawPath(p, ink);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _TracePainter oldDelegate) => true;
}

class PassiveScreen extends StatefulWidget {
  const PassiveScreen({required this.state, super.key});
  final AppState state;

  @override
  State<PassiveScreen> createState() => _PassiveScreenState();
}

class _PassiveScreenState extends State<PassiveScreen> {
  Timer? timer;
  bool playing = false;
  int index = 0;
  double speed = 0.42;
  int delaySeconds = 6;
  List<LearningItem> playlist = const [];

  @override
  void dispose() {
    timer?.cancel();
    widget.state.stopSpeaking();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (playing) {
      timer?.cancel();
      await widget.state.stopSpeaking();
      setState(() => playing = false);
      return;
    }
    playlist = widget.state.filteredItems()..shuffle();
    playlist = playlist.take(100).toList();
    if (playlist.isEmpty) return;
    setState(() => playing = true);
    await _speakCurrent();
    timer = Timer.periodic(Duration(seconds: delaySeconds), (_) async {
      if (!mounted || playlist.isEmpty) return;
      setState(() => index = (index + 1) % playlist.length);
      await _speakCurrent();
    });
  }

  Future<void> _speakCurrent() async {
    if (playlist.isEmpty) return;
    final item = playlist[index];
    await widget.state.speak(item.korean, rate: speed);
  }

  @override
  Widget build(BuildContext context) {
    final item = playlist.isEmpty ? null : playlist[index];
    return ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 28), children: [
      const Text('Học thụ động', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      const Text('Phát lặp tiếng Hàn khi đi bộ hoặc làm việc nhẹ. Không dùng lúc lái xe hay khi cần tập trung an toàn.'),
      const SizedBox(height: 22),
      Container(
        height: 330,
        padding: const EdgeInsets.all(26),
        decoration: BoxDecoration(
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF291D5C), Color(0xFF6C4DFF)]),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(playing ? Icons.graphic_eq_rounded : Icons.headphones_rounded, color: Colors.white70, size: 52),
          const SizedBox(height: 18),
          Text(item?.korean ?? 'Sẵn sàng nghe', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 35, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Text(item?.displayMeaning ?? 'Chọn cấp TOPIK rồi nhấn phát', textAlign: TextAlign.center, maxLines: 3, style: const TextStyle(color: Colors.white70, fontSize: 17, height: 1.4)),
          const SizedBox(height: 24),
          IconButton.filled(
            onPressed: _toggle,
            style: IconButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF4B32B5), padding: const EdgeInsets.all(18)),
            iconSize: 35,
            icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
          ),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('Tốc độ phát âm', style: TextStyle(fontWeight: FontWeight.w700)),
      Slider(value: speed, min: 0.25, max: 0.65, divisions: 8, label: speed.toStringAsFixed(2), onChanged: playing ? null : (v) => setState(() => speed = v)),
      const Text('Khoảng nghỉ giữa các mục', style: TextStyle(fontWeight: FontWeight.w700)),
      Slider(value: delaySeconds.toDouble(), min: 4, max: 12, divisions: 8, label: '$delaySeconds giây', onChanged: playing ? null : (v) => setState(() => delaySeconds = v.round())),
      const SizedBox(height: 6),
      Wrap(spacing: 7, children: [
        for (var level = 0; level <= 6; level++)
          ChoiceChip(label: Text(level == 0 ? 'Mọi cấp' : 'TOPIK $level'), selected: widget.state.selectedLevel == level, onSelected: playing ? null : (_) => widget.state.setLevel(level)),
      ]),
      const SizedBox(height: 16),
      const _InfoBox(icon: Icons.psychology_alt_rounded, text: 'Để học thụ động có tác dụng, hãy ưu tiên mục đã học chủ động. Mỗi khi nghe, thử đoán nghĩa trước khi nhìn màn hình.'),
    ]);
  }
}

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({required this.state, super.key});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final retention = state.learnedCount == 0 ? 0.0 : state.records.values.where((r) => r.repetitions > 1).length / state.learnedCount;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 28), children: [
      const Text('Tiến độ', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 18),
      Row(children: [
        Expanded(child: _Metric(title: 'Đã chạm', value: '${state.learnedCount}', icon: Icons.auto_awesome_rounded)),
        const SizedBox(width: 10),
        Expanded(child: _Metric(title: 'Khắc sâu', value: '${state.masteredCount}', icon: Icons.verified_rounded)),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _Metric(title: 'Đến hạn', value: '${state.dueCount}', icon: Icons.schedule_rounded)),
        const SizedBox(width: 10),
        Expanded(child: _Metric(title: 'Chuỗi', value: '${state.streak} ngày', icon: Icons.local_fire_department_rounded)),
      ]),
      const SizedBox(height: 22),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerLow, borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Độ ổn định ước tính', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          LinearProgressIndicator(value: retention, minHeight: 12, borderRadius: BorderRadius.circular(20)),
          const SizedBox(height: 8),
          Text('${(retention * 100).round()}% mục đã được nhớ đúng ít nhất hai lần'),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('7 ngày gần nhất', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      SizedBox(
        height: 180,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            for (var offset = 6; offset >= 0; offset--)
              Expanded(
                child: _DayBar(
                  date: DateTime.now().subtract(Duration(days: offset)),
                  count: state.dailyReviews[state.dayKey(DateTime.now().subtract(Duration(days: offset)))] ?? 0,
                  maxValue: max(1, state.dailyGoal),
                ),
              ),
          ],
        ),
      ),
      const SizedBox(height: 18),
      const _InfoBox(icon: Icons.info_outline_rounded, text: '“Khắc sâu” trong app nghĩa là đã ôn ít nhất 5 lần và khoảng cách ôn đạt 21 ngày. Không có thuật toán nào bảo đảm con người “không bao giờ quên”; app giảm quên bằng nhắc lại đúng lúc.'),
    ]);
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({required this.state, super.key});
  final AppState state;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 28), children: [
      const Text('Cài đặt', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 18),
      ListTile(
        tileColor: Theme.of(context).colorScheme.surfaceContainerLow,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        leading: const Icon(Icons.flag_rounded),
        title: const Text('Mục tiêu mỗi ngày'),
        subtitle: Text('${widget.state.dailyGoal} lượt nhớ lại'),
        trailing: DropdownButton<int>(
          value: widget.state.dailyGoal,
          underline: const SizedBox.shrink(),
          items: const [10, 20, 30, 50, 80, 100].map((v) => DropdownMenuItem(value: v, child: Text('$v'))).toList(),
          onChanged: (value) => value == null ? null : widget.state.setDailyGoal(value),
        ),
      ),
      const SizedBox(height: 12),
      ListTile(
        tileColor: Theme.of(context).colorScheme.surfaceContainerLow,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        leading: widget.state.syncing ? const CircularProgressIndicator() : const Icon(Icons.cloud_download_rounded),
        title: const Text('Đồng bộ gói dữ liệu đầy đủ'),
        subtitle: const Text('Tải danh mục NIKL/FoldAlpha và 290 mẫu ngữ pháp. Cần Internet; dữ liệu được lưu để học offline.'),
        trailing: const Icon(Icons.chevron_right),
        onTap: widget.state.syncing ? null : _sync,
      ),
      const SizedBox(height: 12),
      ListTile(
        tileColor: Theme.of(context).colorScheme.errorContainer,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        leading: const Icon(Icons.restart_alt_rounded),
        title: const Text('Xóa toàn bộ tiến độ'),
        subtitle: const Text('Không xóa gói dữ liệu đã tải'),
        onTap: _confirmReset,
      ),
      const SizedBox(height: 22),
      const Text('Nguồn và phạm vi dữ liệu', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      const _InfoBox(
        icon: Icons.verified_user_outlined,
        text: 'Từ vựng: danh mục 5.965 mục của Viện Quốc ngữ Hàn Quốc, nghĩa Việt/ví dụ từ FoldAlpha; mức 1–6 được đối chiếu thêm với danh mục International Standard Curriculum. Ngữ pháp: 290 mẫu theo ba dải học, không phải danh sách TOPIK chính thức.',
      ),
      const SizedBox(height: 10),
      const _InfoBox(
        icon: Icons.gavel_rounded,
        text: 'Ghi nguồn: National Institute of Korean Language (KOGL Type 1); Korean Learners’ Dictionary (CC BY-SA 2.0 KR); FoldAlpha; CheesePotato/EveryKoreans. Không phân phối đề thi có bản quyền.',
      ),
      if (widget.state.error != null) ...[
        const SizedBox(height: 12),
        _InfoBox(icon: Icons.error_outline, text: widget.state.error!),
      ],
      const SizedBox(height: 18),
      const Center(child: Text('TOPIK Khắc Sâu 1.0.0 • Flutter', style: TextStyle(color: Colors.grey))),
    ]);
  }

  Future<void> _sync() async {
    try {
      final message = await widget.state.sync();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Không tải được dữ liệu. Hãy kiểm tra Internet hoặc thử lại sau.')));
    }
  }

  Future<void> _confirmReset() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xóa tiến độ?'),
        content: const Text('Toàn bộ lịch ôn, chuỗi ngày và thống kê sẽ bị xóa. Hành động này không hoàn tác được.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirmed == true) await widget.state.resetProgress();
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(99)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 16), const SizedBox(width: 5), Text(text, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12))]),
      );
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({required this.color, required this.iconColor, required this.icon, required this.title, required this.subtitle, required this.onTap});
  final Color color;
  final Color iconColor;
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Ink(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(22)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, color: iconColor, size: 31),
            const SizedBox(height: 18),
            Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            Text(subtitle),
          ]),
        ),
      );
}

class _WideAction extends StatelessWidget {
  const _WideAction({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ListTile(
        tileColor: Theme.of(context).colorScheme.surfaceContainerLow,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: onTap,
      );
}

class _RatingButton extends StatelessWidget {
  const _RatingButton({required this.label, required this.color, required this.onTap});
  final String label;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Expanded(
        child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: color, padding: const EdgeInsets.symmetric(vertical: 13), minimumSize: Size.zero),
          onPressed: onTap,
          child: Text(label),
        ),
      );
}

class _InfoBox extends StatelessWidget {
  const _InfoBox({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerLow, borderRadius: BorderRadius.circular(18)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon), const SizedBox(width: 12), Expanded(child: Text(text, style: const TextStyle(height: 1.45)))]),
      );
}

class _Metric extends StatelessWidget {
  const _Metric({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerLow, borderRadius: BorderRadius.circular(22)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 14), Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)), Text(title)]),
      );
}

class _DayBar extends StatelessWidget {
  const _DayBar({required this.date, required this.count, required this.maxValue});
  final DateTime date;
  final int count;
  final int maxValue;
  @override
  Widget build(BuildContext context) {
    final fraction = (count / maxValue).clamp(0.03, 1.0).toDouble();
    const names = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
        Text('$count', style: const TextStyle(fontSize: 11)),
        const SizedBox(height: 5),
        Flexible(
          child: FractionallySizedBox(
            heightFactor: fraction,
            child: Container(decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(10))),
          ),
        ),
        const SizedBox(height: 7),
        Text(names[date.weekday - 1], style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
      ]),
    );
  }
}
