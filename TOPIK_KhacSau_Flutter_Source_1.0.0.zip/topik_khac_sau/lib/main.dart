import 'package:flutter/material.dart';

import 'app_state.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TopikKhacSauBootstrap());
}

class TopikKhacSauBootstrap extends StatefulWidget {
  const TopikKhacSauBootstrap({super.key});

  @override
  State<TopikKhacSauBootstrap> createState() => _TopikKhacSauBootstrapState();
}

class _TopikKhacSauBootstrapState extends State<TopikKhacSauBootstrap> {
  late final AppState state;

  @override
  void initState() {
    super.initState();
    state = AppState()..initialize();
  }

  @override
  void dispose() {
    state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => TopikKhacSauApp(state: state);
}

class TopikKhacSauApp extends StatelessWidget {
  const TopikKhacSauApp({required this.state, super.key});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF6C4DFF);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TOPIK Khắc Sâu',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.light,
          surface: const Color(0xFFF9F8FF),
        ),
        useMaterial3: true,
        fontFamilyFallback: const ['Noto Sans', 'Roboto'],
        cardTheme: const CardThemeData(
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(22)),
          ),
        ),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(18)),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: HomeScreen(state: state),
    );
  }
}
