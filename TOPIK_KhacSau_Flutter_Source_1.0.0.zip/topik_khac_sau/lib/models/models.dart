enum ItemType { vocabulary, grammar }

class LearningItem {
  const LearningItem({
    required this.id,
    required this.korean,
    required this.meaning,
    required this.example,
    required this.level,
    required this.type,
    this.partOfSpeech = '',
    this.hanja = '',
    this.source = '',
    this.meaningEn = '',
  });

  final String id;
  final String korean;
  final String meaning;
  final String meaningEn;
  final String example;
  final int level;
  final ItemType type;
  final String partOfSpeech;
  final String hanja;
  final String source;

  String get displayMeaning => meaning.trim().isNotEmpty ? meaning : meaningEn;

  factory LearningItem.fromVocab(Map<String, dynamic> json) => LearningItem(
        id: json['id'] as String,
        korean: json['word'] as String,
        meaning: (json['meaningVi'] ?? '') as String,
        example: (json['exampleKo'] ?? '') as String,
        level: ((json['level'] as num?)?.toInt() ?? 1).clamp(1, 6).toInt(),
        type: ItemType.vocabulary,
        partOfSpeech: (json['pos'] ?? '') as String,
        hanja: (json['hanja'] ?? '') as String,
        source: (json['source'] ?? '') as String,
      );

  factory LearningItem.fromGrammar(Map<String, dynamic> json) => LearningItem(
        id: json['id'] as String,
        korean: json['pattern'] as String,
        meaning: (json['meaningVi'] ?? '') as String,
        meaningEn: (json['meaningEn'] ?? '') as String,
        example: (json['exampleKo'] ?? '') as String,
        level: ((json['level'] as num?)?.toInt() ?? 1).clamp(1, 6).toInt(),
        type: ItemType.grammar,
        source: (json['source'] ?? '') as String,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'korean': korean,
        'meaning': meaning,
        'meaningEn': meaningEn,
        'example': example,
        'level': level,
        'type': type.name,
        'partOfSpeech': partOfSpeech,
        'hanja': hanja,
        'source': source,
      };

  factory LearningItem.fromCache(Map<String, dynamic> json) => LearningItem(
        id: json['id'] as String,
        korean: json['korean'] as String,
        meaning: (json['meaning'] ?? '') as String,
        meaningEn: (json['meaningEn'] ?? '') as String,
        example: (json['example'] ?? '') as String,
        level: (json['level'] as num).toInt(),
        type: ItemType.values.byName(json['type'] as String),
        partOfSpeech: (json['partOfSpeech'] ?? '') as String,
        hanja: (json['hanja'] ?? '') as String,
        source: (json['source'] ?? '') as String,
      );
}

enum RecallRating { again, hard, good, easy }

class ReviewRecord {
  const ReviewRecord({
    required this.itemId,
    required this.due,
    this.repetitions = 0,
    this.lapses = 0,
    this.intervalDays = 0,
    this.ease = 2.5,
    this.lastReviewed,
  });

  final String itemId;
  final DateTime due;
  final int repetitions;
  final int lapses;
  final double intervalDays;
  final double ease;
  final DateTime? lastReviewed;

  bool isDue(DateTime now) => !due.isAfter(now);
  bool get isMastered => repetitions >= 5 && intervalDays >= 21;

  Map<String, dynamic> toJson() => {
        'itemId': itemId,
        'due': due.toIso8601String(),
        'repetitions': repetitions,
        'lapses': lapses,
        'intervalDays': intervalDays,
        'ease': ease,
        'lastReviewed': lastReviewed?.toIso8601String(),
      };

  factory ReviewRecord.fromJson(Map<String, dynamic> json) => ReviewRecord(
        itemId: json['itemId'] as String,
        due: DateTime.parse(json['due'] as String),
        repetitions: (json['repetitions'] as num?)?.toInt() ?? 0,
        lapses: (json['lapses'] as num?)?.toInt() ?? 0,
        intervalDays: (json['intervalDays'] as num?)?.toDouble() ?? 0,
        ease: (json['ease'] as num?)?.toDouble() ?? 2.5,
        lastReviewed: json['lastReviewed'] == null
            ? null
            : DateTime.parse(json['lastReviewed'] as String),
      );
}
