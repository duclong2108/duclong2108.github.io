# Data sources manifest

Checked on 2026-11-18.

| Component | Source | In-app use | Notes |
|---|---|---|---|
| Korean learner vocabulary | https://topikvocab.foldalpha.com/download/ | Remote CSV sync | 5,965 words; Vietnamese meaning, hanja and example where supplied; underlying vocabulary credited to NIKL, KOGL Type 1. |
| TOPIK 1–6 study mapping | https://everykoreans.com/topik-vocabulary-list/ | Remote level merge | 10,189 headwords; levels are a study convention based on the International Standard Curriculum, not an official TOPIK list. |
| Grammar patterns | https://everykoreans.com/topik-grammar-list/ | 290-item seed and remote refresh | Three teaching bands; not an official TOPIK grammar list. 183 source rows were retrievable during generation; the remainder were curated as clearly labelled study entries. |
| Dictionary API reference | https://krdict.korean.go.kr/vie/openApi/openApiInfo | Reference for a future verified dictionary lookup | Requires a user-registered API key; the key is not embedded in this app. |
| Spaced repetition background | https://github.com/open-spaced-repetition/awesome-fsrs/wiki/The-Algorithm | Design reference only | App 1.0 ships a deterministic SM-2-style scheduler, not a claim of full FSRS conformance. |

## Important distinction

TOPIK publishes exam levels, but does not publish one canonical vocabulary list mapping every word to levels 1–6. The app therefore labels levels as a learning sequence, not as an official examination ruling.
