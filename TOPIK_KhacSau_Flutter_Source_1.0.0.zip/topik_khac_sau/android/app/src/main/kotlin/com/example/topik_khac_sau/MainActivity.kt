package com.example.topik_khac_sau

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
