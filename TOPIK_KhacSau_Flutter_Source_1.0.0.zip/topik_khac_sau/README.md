# TOPIK Khắc Sâu — Flutter

Ứng dụng học tiếng Hàn cho người Việt, tập trung vào **truy hồi chủ động**, **lặp lại ngắt quãng**, nghe thụ động có kiểm soát và luyện nhớ mặt chữ.

## Có gì trong bản 1.0

- Phiên ôn từ vựng/ngữ pháp với 4 mức phản hồi: **Quên / Khó / Nhớ / Dễ**.
- Bộ lập lịch kiểu SM-2 cải tiến: mục quên quay lại sau 10 phút; mục nhớ tốt được giãn dần.
- Thư viện tìm kiếm theo tiếng Hàn, nghĩa, ví dụ và cấp TOPIK 1–6.
- 290 mục ngữ pháp đóng gói; 88 từ vựng khởi động tiếng Việt để app chạy hoàn toàn offline ngay lần đầu.
- Nút **Đồng bộ gói dữ liệu đầy đủ** tải danh mục 5.965 từ có nghĩa Việt và ví dụ; app đối chiếu thêm danh mục cấp 1–6 khi nguồn đó khả dụng.
- Học thụ động bằng TTS tiếng Hàn, điều chỉnh tốc độ và khoảng nghỉ.
- Bảng luyện viết trên lưới: hiện/ẩn chữ mờ, viết bằng ngón tay và xóa để viết lại.
- Lưu tiến độ cục bộ, mục tiêu ngày, chuỗi ngày, số mục đến hạn và mốc “khắc sâu”.
- Không quảng cáo, không tài khoản, không gửi dữ liệu học tập ra máy chủ.

> **Giới hạn cần hiểu đúng:** TOPIK không công bố một danh sách từ vựng/ngữ pháp chính thức phân tách tuyệt đối thành từng cấp 1–6. Cấp trong ứng dụng là ánh xạ học tập từ *International Standard Curriculum for Korean Language Education* và dải NIKL. “Khắc sâu” giúp giảm quên, không thể bảo đảm sinh học rằng người học sẽ không bao giờ quên.

## Nguồn dữ liệu và giấy phép

1. National Institute of Korean Language (NIKL), danh mục 5.965 từ: KOGL Type 1 — được dùng lại với ghi nguồn.
2. Korean Learners’ Dictionary: CC BY-SA 2.0 KR.
3. FoldAlpha: bản nghĩa Việt và ví dụ trong gói tải 5.965 từ.
4. CheesePotato / EveryKoreans: ánh xạ danh mục cấp 1–6 và danh sách 290 mẫu ngữ pháp; đây là tài liệu học, không phải danh sách TOPIK chính thức.

Ứng dụng không đóng gói đề thi TOPIK có bản quyền. Khi phát hành công khai, phải giữ phần ghi nguồn trong màn hình **Cài đặt** và tuân thủ điều kiện của nguồn tại thời điểm phát hành.

## Cài APK đã build

1. Chép `app-release.apk` vào điện thoại Android.
2. Mở tệp bằng trình quản lý tệp.
3. Nếu Android hỏi, bật **Cho phép cài ứng dụng không rõ nguồn gốc** cho đúng trình quản lý tệp đang dùng.
4. Chọn **Cài đặt**.
5. Mở app → **Cài đặt** → **Đồng bộ gói dữ liệu đầy đủ** khi có Internet.
6. Cài giọng đọc tiếng Hàn trong Android nếu máy chưa có: **Cài đặt hệ thống → Chuyển văn bản thành giọng nói → tải Korean/한국어**.

Android tối thiểu: API 23 (Android 6.0).

## Tự build APK

### Yêu cầu

- Flutter stable 3.35 trở lên; Dart đi kèm Flutter.
- Android Studio hoặc Android command-line SDK; JDK 17.
- Chấp nhận Android SDK licenses bằng `flutter doctor --android-licenses`.

### Windows

1. Giải nén dự án.
2. Mở `tool/BUILD_ANDROID.bat`.
3. Script tự tạo lại wrapper Android, tải package, format, analyze, test và build.
4. APK nằm tại `build\app\outputs\flutter-apk\app-release.apk`.

### macOS / Linux

```bash
cd topik_khac_sau
./tool/build_android.sh
```

Hoặc chạy thủ công:

```bash
flutter create --platforms=android .
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --release
```

### GitHub Actions

Workflow `.github/workflows/build-android.yml` chạy đầy đủ format → analyze → test → build và tạo artifact `topik-khac-sau-apk`. Đẩy mã nguồn lên GitHub, mở **Actions → Build Android APK → Run workflow**, sau đó tải artifact.

## Kiểm tra dữ liệu

```bash
python3 tool/check_data.py
```

Bộ kiểm tra xác nhận:

- JSON đọc được bằng UTF-8;
- đúng 290 mục ngữ pháp đóng gói;
- không trùng ID hoặc mẫu;
- mọi mục có cấp 1–6 hợp lệ;
- không có ký tự điều khiển ẩn.

## Cấu trúc chính

```text
lib/
  app_state.dart                 # trạng thái, lưu tiến độ, TTS
  main.dart                      # theme và bootstrap
  models/models.dart             # LearningItem, ReviewRecord
  services/data_repository.dart  # seed/cache/sync CSV
  services/scheduler.dart        # thuật toán giãn cách
  screens/home_screen.dart       # toàn bộ luồng UI
assets/data/
  vocab_seed.json
  grammar_seed.json
test/
  scheduler_test.dart
  model_test.dart
```

## Thiết kế học tập

- **Nhìn → tự trả lời → lật đáp án** thay vì chỉ đọc lại.
- Mục “Quên” quay lại sớm; mục “Dễ” cách xa hơn để không lãng phí thời gian.
- Nghe thụ động là phần bổ sung, không thay thế việc tự nhớ lại.
- Bảng viết giúp nhớ hình dạng chữ; bản 1.0 chưa chấm đúng thứ tự từng nét. Muốn chấm nét chính xác cần bổ sung bộ vector stroke-order có giấy phép phù hợp.
- App chủ động nhắc nghỉ; không dùng streak, thông báo hoặc phần thưởng theo cách gây áp lực hay thao túng người học.

## Xử lý lỗi thường gặp

- **Không đọc tiếng Hàn:** tải giọng Korean trong cài đặt TTS của Android rồi khởi động lại app.
- **Đồng bộ thất bại:** thử mạng khác; app vẫn dùng 378 mục đóng gói (88 từ + 290 ngữ pháp).
- **`flutter.sdk not set`:** chạy `flutter create --platforms=android .` từ thư mục gốc.
- **Lỗi license Android:** chạy `flutter doctor --android-licenses`.
- **Gradle/JDK:** xác nhận `java -version` là JDK 17 và `flutter doctor -v` không còn lỗi Android toolchain.
