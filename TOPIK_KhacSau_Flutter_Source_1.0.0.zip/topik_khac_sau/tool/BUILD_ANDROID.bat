@echo off
cd /d %~dp0\..
call flutter create --platforms=android . || exit /b 1
call flutter pub get || exit /b 1
call dart format lib test || exit /b 1
call flutter analyze || exit /b 1
call flutter test || exit /b 1
call flutter build apk --release || exit /b 1
echo APK: build\app\outputs\flutter-apk\app-release.apk
pause
