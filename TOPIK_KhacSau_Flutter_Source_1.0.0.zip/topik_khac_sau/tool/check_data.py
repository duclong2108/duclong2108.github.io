#!/usr/bin/env python3
import json, pathlib, re, sys
root = pathlib.Path(__file__).resolve().parents[1]
errors=[]
for filename, expected, key in [('vocab_seed.json',None,'word'),('grammar_seed.json',290,'pattern')]:
    path=root/'assets'/'data'/filename
    try: data=json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc: errors.append(f'{filename}: JSON lỗi: {exc}'); continue
    if expected is not None and len(data)!=expected: errors.append(f'{filename}: cần {expected}, có {len(data)}')
    ids=[x.get('id') for x in data]
    if len(ids)!=len(set(ids)): errors.append(f'{filename}: trùng id')
    values=[]
    for i,x in enumerate(data,1):
        value=str(x.get(key,'')).strip()
        if not value: errors.append(f'{filename} dòng {i}: thiếu {key}')
        values.append(value)
        level=x.get('level')
        if not isinstance(level,int) or not 1<=level<=6: errors.append(f'{filename} dòng {i}: level không hợp lệ')
        if re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f]',json.dumps(x,ensure_ascii=False)):
            errors.append(f'{filename} dòng {i}: ký tự điều khiển')
    if len(values)!=len(set(values)): errors.append(f'{filename}: trùng {key}')
    print(f'{filename}: {len(data)} mục, {len(set(ids))} id duy nhất, TOPIK 1–6 hợp lệ')
if errors:
    print('\n'.join('ERROR: '+e for e in errors)); sys.exit(1)
print('DATA CHECK: PASS')
