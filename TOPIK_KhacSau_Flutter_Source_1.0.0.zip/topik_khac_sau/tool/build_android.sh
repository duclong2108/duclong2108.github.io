#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flutter create --platforms=android .
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --release
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
