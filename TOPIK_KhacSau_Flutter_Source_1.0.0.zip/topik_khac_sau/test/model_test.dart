import 'package:flutter_test/flutter_test.dart';
import 'package:topik_khac_sau/models/models.dart';

void main() {
  test('ReviewRecord round-trips JSON', () {
    final source = ReviewRecord(
      itemId: 'x',
      due: DateTime.utc(2026, 11, 20),
      repetitions: 4,
      intervalDays: 15,
      ease: 2.4,
    );
    final restored = ReviewRecord.fromJson(source.toJson());
    expect(restored.itemId, source.itemId);
    expect(restored.due, source.due);
    expect(restored.intervalDays, 15);
  });
}
