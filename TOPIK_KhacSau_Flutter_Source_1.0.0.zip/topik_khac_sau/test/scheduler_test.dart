import 'package:flutter_test/flutter_test.dart';
import 'package:topik_khac_sau/models/models.dart';
import 'package:topik_khac_sau/services/scheduler.dart';

void main() {
  const scheduler = MemoryScheduler();
  final now = DateTime.utc(2026, 11, 18, 12);

  test('Again schedules a relearn in ten minutes', () {
    final result = scheduler.schedule(null, 'v1', RecallRating.again, now);
    expect(result.due, now.add(const Duration(minutes: 10)));
    expect(result.lapses, 1);
    expect(result.repetitions, 0);
  });

  test('Good grows intervals monotonically', () {
    final first = scheduler.schedule(null, 'v1', RecallRating.good, now);
    final second = scheduler.schedule(first, 'v1', RecallRating.good, first.due);
    final third = scheduler.schedule(second, 'v1', RecallRating.good, second.due);
    expect(first.intervalDays, 1);
    expect(second.intervalDays, 3);
    expect(third.intervalDays, greaterThan(second.intervalDays));
  });

  test('Easy starts later than Good', () {
    final good = scheduler.schedule(null, 'v1', RecallRating.good, now);
    final easy = scheduler.schedule(null, 'v2', RecallRating.easy, now);
    expect(easy.due.isAfter(good.due), isTrue);
  });
}
